# Stencyl-Better-Logic
Extension for the Stencylworks game engine that adds better logic blocks such as switch case statements and ternary operator
